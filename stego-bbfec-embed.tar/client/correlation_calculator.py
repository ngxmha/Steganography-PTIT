import numpy as np
import wave
import sys

def read_wav(file_path):
    with wave.open(file_path, 'rb') as wf:
        frames = wf.readframes(wf.getnframes())
        samples = np.frombuffer(frames, dtype=np.int16)
    return samples

def calculate_correlation(x, y):
    return np.corrcoef(x, y)[0, 1]

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python correlation_calculator.py <file goc> <file giau tin>")
        sys.exit(1)

    file1, file2 = sys.argv[1], sys.argv[2]
    samples1 = read_wav(file1)
    samples2 = read_wav(file2)

    min_len = min(len(samples1), len(samples2))
    samples1 = samples1[:min_len]
    samples2 = samples2[:min_len]

    corr = calculate_correlation(samples1, samples2)
    print(f"Correlation Coefficient: {corr}")
