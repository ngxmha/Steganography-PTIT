import numpy as np
import matplotlib.pyplot as plt
import wave
import sys

def read_wav_file(file_path):
    with wave.open(file_path, 'r') as wav_file:
        signal = wav_file.readframes(-1)
        signal = np.frombuffer(signal, dtype=np.int16)
        frame_rate = wav_file.getframerate()
        num_frames = wav_file.getnframes()
        duration = num_frames / frame_rate
        time = np.linspace(0, duration, num=len(signal))
    return time, signal

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 plot_wav.py <file goc> <file stego>")
        sys.exit(1)

    file_path1 = sys.argv[1]  # File goc
    file_path2 = sys.argv[2]  # File stego

    time1, signal1 = read_wav_file(file_path1)
    time2, signal2 = read_wav_file(file_path2)

    plt.figure(figsize=(12, 6))

    # Hinh 1: File goc
    plt.subplot(2, 1, 1)
    plt.plot(time1, signal1)
    plt.title("Waveform of Original File: " + file_path1)
    plt.xlabel("Time [s]")
    plt.ylabel("Amplitude")
    plt.grid()

    # Hinh 2: File stego
    plt.subplot(2, 1, 2)
    plt.plot(time2, signal2, color='orange')
    plt.title("Waveform of Stego File: " + file_path2)
    plt.xlabel("Time [s]")
    plt.ylabel("Amplitude")
    plt.grid()

    plt.tight_layout()
    plt.show()
