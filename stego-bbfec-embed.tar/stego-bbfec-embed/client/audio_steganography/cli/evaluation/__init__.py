stat_df_columns = [
    'dataset',
    'category',
    'file',
    'method',
    'params',
    'secret_bits',
    'modification',
    'ber_percent',
    'snr_db',
    'psnr_db',
    'mse',
    'rmsd',
    'time_to_encode',
    'time_to_decode',
]

